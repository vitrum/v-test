﻿var sitemap = 
{
"rootNodes":[
{
"pageName":"Greenzetta Vote",
"type":"Wireframe",
"url":"Greenzetta_Vote.html",
"children":[
{
"pageName":"blog",
"type":"Wireframe",
"url":"blog.html",
"children":[
{
"pageName":"finish vote 1",
"type":"Wireframe",
"url":"finish_vote_1.html"},
{
"pageName":"finish vote 2",
"type":"Wireframe",
"url":"finish_vote_2.html"}]},
{
"pageName":"admin",
"type":"Wireframe",
"url":"admin.html"}]}]};
