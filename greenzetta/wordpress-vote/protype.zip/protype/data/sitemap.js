﻿var sitemap = 
{
"rootNodes":[
{
"pageName":"Greenzeeta Vote",
"type":"Wireframe",
"url":"Greenzeeta_Vote.html",
"children":[
{
"pageName":"blog",
"type":"Wireframe",
"url":"blog.html",
"children":[
{
"pageName":"finish vote 1",
"type":"Wireframe",
"url":"finish_vote_1.html"},
{
"pageName":"finish vote 2",
"type":"Wireframe",
"url":"finish_vote_2.html"}]},
{
"pageName":"admin",
"type":"Wireframe",
"url":"admin.html"}]}]};
